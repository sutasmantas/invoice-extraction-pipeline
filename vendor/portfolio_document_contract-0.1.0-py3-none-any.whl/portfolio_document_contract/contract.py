from __future__ import annotations

import hashlib
import json
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from importlib.resources import files
from typing import Literal

import psutil
from jsonschema import Draft202012Validator

CONTRACT_VERSION = "portfolio.normalized-document.v1"


@dataclass(frozen=True)
class Budget:
    max_input_bytes: int = 10 * 1024 * 1024
    max_pages: int = 25
    fast_route_max_processing_ms: float = 1000
    quality_route_max_processing_ms: float = 45000
    max_peak_rss_delta_mb: float = 4096


@dataclass(frozen=True)
class DocumentRequest:
    content: bytes
    filename: str
    media_type: str
    source_uri: str | None = None


@dataclass(frozen=True)
class ParsedTable:
    markdown: str
    row_count: int
    column_count: int
    bbox: tuple[float, float, float, float] | None = None


@dataclass(frozen=True)
class ParsedPage:
    page_number: int
    text: str
    markdown: str | None = None
    tables: tuple[ParsedTable, ...] = ()
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True)
class Capabilities:
    page_boundaries: Literal["exact", "inferred", "unavailable"]
    tables: Literal["preserved", "flattened", "unavailable"]
    coordinates: Literal["exact", "approximate", "unavailable"]
    ocr: bool


@dataclass(frozen=True)
class ParsedDocument:
    document_format: str
    pages: tuple[ParsedPage, ...]
    capabilities: Capabilities
    title: str | None = None


@dataclass(frozen=True)
class ParserIdentity:
    name: str
    version: str
    route: Literal["fast", "quality", "fallback", "none"]
    degraded: bool = False
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class ParserOutcome:
    identity: ParserIdentity
    document: ParsedDocument


class DocumentContractError(Exception):
    failure_class = "internal_error"
    retryable = False


class EmptyDocumentError(DocumentContractError):
    failure_class = "empty_document"


class MalformedDocumentError(DocumentContractError):
    failure_class = "malformed_document"


class UnsupportedFormatError(DocumentContractError):
    failure_class = "unsupported_format"


class ParserUnavailableError(DocumentContractError):
    failure_class = "parser_unavailable"
    retryable = True


class ResourceLimitError(DocumentContractError):
    failure_class = "resource_limit"
    retryable = True


def _schema() -> dict:
    resource = files("portfolio_document_contract").joinpath("normalized_document.schema.json")
    return json.loads(resource.read_text(encoding="utf-8"))


def schema_sha256() -> str:
    canonical = json.dumps(_schema(), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()


def validate_result(result: dict) -> None:
    Draft202012Validator(_schema()).validate(result)


def _identity(value: ParserIdentity) -> dict:
    return {
        "name": value.name,
        "version": value.version,
        "route": value.route,
        "degraded": value.degraded,
        "notes": list(value.notes),
    }


def _source(request: DocumentRequest) -> dict:
    return {
        "filename": request.filename,
        "media_type": request.media_type,
        "sha256": hashlib.sha256(request.content).hexdigest(),
        "size_bytes": len(request.content),
        "source_uri": request.source_uri,
    }


def _metrics(started: float, baseline_rss: int, peak_rss: list[int]) -> dict:
    return {
        "processing_ms": round((time.perf_counter() - started) * 1000, 3),
        "peak_rss_delta_mb": round(max(0, peak_rss[0] - baseline_rss) / 1024**2, 3),
    }


def _failure(
    request: DocumentRequest,
    identity: ParserIdentity,
    metrics: dict,
    error: DocumentContractError,
) -> dict:
    result = {
        "contract_version": CONTRACT_VERSION,
        "status": "error",
        "source": _source(request),
        "parser": _identity(identity),
        "metrics": metrics,
        "failure": {
            "class": error.failure_class,
            "message": str(error) or type(error).__name__,
            "retryable": error.retryable,
        },
    }
    validate_result(result)
    return result


def execute(
    request: DocumentRequest,
    parser: Callable[[DocumentRequest], ParserOutcome],
    *,
    declared_parser: ParserIdentity,
    budget: Budget | None = None,
) -> dict:
    """Run one consumer parser behind the frozen result and resource contract."""

    budget = budget or Budget()
    started = time.perf_counter()
    process = psutil.Process()
    baseline_rss = process.memory_info().rss
    peak_rss = [baseline_rss]
    stop = threading.Event()

    def sample_rss() -> None:
        while not stop.wait(0.01):
            peak_rss[0] = max(peak_rss[0], process.memory_info().rss)

    sampler = threading.Thread(target=sample_rss, daemon=True)
    sampler.start()
    identity = declared_parser
    try:
        if not request.content:
            raise EmptyDocumentError("document contains zero bytes")
        if len(request.content) > budget.max_input_bytes:
            raise ResourceLimitError(
                f"input has {len(request.content)} bytes; limit is {budget.max_input_bytes}"
            )
        outcome = parser(request)
        identity = outcome.identity
        pages = sorted(outcome.document.pages, key=lambda page: page.page_number)
        if not pages or any(not page.text.strip() for page in pages):
            raise EmptyDocumentError("parser produced no non-empty pages")
        if len({page.page_number for page in pages}) != len(pages):
            raise MalformedDocumentError("parser produced duplicate page numbers")
        if len(pages) > budget.max_pages:
            raise ResourceLimitError(
                f"document has {len(pages)} pages; limit is {budget.max_pages}"
            )
        rendered_pages = []
        table_count = 0
        for page in pages:
            rendered_tables = []
            for index, table in enumerate(page.tables, start=1):
                rendered_tables.append(
                    {
                        "table_index": index,
                        "markdown": table.markdown,
                        "row_count": table.row_count,
                        "column_count": table.column_count,
                        "bbox": list(table.bbox) if table.bbox else None,
                    }
                )
            table_count += len(rendered_tables)
            rendered_pages.append(
                {
                    "page_number": page.page_number,
                    "text": page.text.strip(),
                    "markdown": (page.markdown or page.text).strip(),
                    "tables": rendered_tables,
                    "warnings": list(page.warnings),
                }
            )
        stop.set()
        sampler.join(timeout=0.1)
        metrics = _metrics(started, baseline_rss, peak_rss)
        route_limit = (
            budget.fast_route_max_processing_ms
            if identity.route == "fast"
            else budget.quality_route_max_processing_ms
        )
        if metrics["processing_ms"] > route_limit:
            raise ResourceLimitError(
                f"{identity.route} route took {metrics['processing_ms']} ms; limit is {route_limit}"
            )
        if metrics["peak_rss_delta_mb"] > budget.max_peak_rss_delta_mb:
            raise ResourceLimitError(
                f"peak RSS delta was {metrics['peak_rss_delta_mb']} MiB; "
                f"limit is {budget.max_peak_rss_delta_mb}"
            )
        text = "\n\n".join(page["text"] for page in rendered_pages)
        markdown = "\n\n".join(page["markdown"] for page in rendered_pages)
        result = {
            "contract_version": CONTRACT_VERSION,
            "status": "success",
            "source": _source(request),
            "parser": _identity(identity),
            "metrics": metrics,
            "document": {
                "document_format": outcome.document.document_format,
                "title": outcome.document.title,
                "pages": rendered_pages,
                "structure": {
                    "pages": len(rendered_pages),
                    "characters": len(text),
                    "headings": sum(
                        line.lstrip().startswith("#") for line in markdown.splitlines()
                    ),
                    "tables": table_count,
                },
                "capabilities": {
                    "page_boundaries": outcome.document.capabilities.page_boundaries,
                    "tables": outcome.document.capabilities.tables,
                    "coordinates": outcome.document.capabilities.coordinates,
                    "ocr": outcome.document.capabilities.ocr,
                },
            },
        }
        validate_result(result)
        return result
    except DocumentContractError as error:
        stop.set()
        sampler.join(timeout=0.1)
        return _failure(request, identity, _metrics(started, baseline_rss, peak_rss), error)
    except Exception as error:
        stop.set()
        sampler.join(timeout=0.1)
        wrapped = DocumentContractError(f"{type(error).__name__}: {error}")
        return _failure(request, identity, _metrics(started, baseline_rss, peak_rss), wrapped)
